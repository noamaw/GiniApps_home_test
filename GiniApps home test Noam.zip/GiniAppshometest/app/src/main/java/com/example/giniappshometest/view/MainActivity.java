package com.example.giniappshometest.view;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;

import android.os.Bundle;
import android.widget.GridView;
import android.widget.TextView;

import com.example.giniappshometest.R;
import com.example.giniappshometest.logic.Helper;
import com.example.giniappshometest.model.Number;
import com.example.giniappshometest.model.NumberList;
import com.example.giniappshometest.viewModel.NumbersViewModel;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    int[] numbers;
    NumbersViewModel numbersViewModel;
    TextView mainTxt;
    GridView gridView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gridView = findViewById(R.id.grid_view);
        initVm();
    }

    private void initVm() {
        numbersViewModel = ViewModelProviders.of(this).get(NumbersViewModel.class);
        numbersViewModel.initialize();

        numbersViewModel.getNumbersRepository().observe(this, new Observer<int[]>() {
            @Override
            public void onChanged(int[] numberList) {
                numbers = numberList;
                updateView();
            }
        });
    }

    public void updateView() {
        NumbersAdapter numbersAdapter = new NumbersAdapter(this, numbers, Helper.findPairs(numbers));
        gridView.setAdapter(numbersAdapter);
    }
}
